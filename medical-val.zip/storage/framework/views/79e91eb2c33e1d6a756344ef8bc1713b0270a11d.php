<?php $__env->startSection('content'); ?>
<html>
    <head>
        <!-- DataTables -->
        <link rel="stylesheet" href="<?php echo e(asset('/css/dataTables.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/css/responsive.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/css/buttons.bootstrap4.min.css')); ?>">
    </head>
    <body>
        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1>Add New Admin</h1>
                        </div>
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
                            <li class="breadcrumb-item active">Add New Admin</li>
                            </ol>
                        </div>
                    </div>
                        <!-- Success message -->
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php endif; ?>
                         <!-- Message message -->
                         <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- jquery validation -->
                        <div class="card card-primary">

                        <!-- form start -->
                        <form action="<?php echo e(route('admin.inviteadmin')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label >Name</label>
                                    <input type="text" name="name" class="form-control" id="name" placeholder="Enter Admin Name">
                                </div>
                                <div class="form-group">
                                    <label >Email address</label>
                                    <input type="email" name="email" class="form-control" id="email" placeholder="Enter Admin Email">
                                </div>
                                <div class="form-group">
                                    
                                    <input type="hidden" name="password" class="form-control" id="password" value="123Abcabc" placeholder="Password">
                                </div>
                                <div class="form-group">
                                    <label>Register as: </label>
                                    <select name="role" class="block mt-1 w-full border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm">
                                        <option value="admin">Admin</option>
                                        <option value="editoradmin">EditorAdmin</option>
                                    </select>
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Send</button>
                                </div>
                            </div>
                        </form>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                        </div>
                    </div>
                    <!-- /.row -->
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        </div>
        <!-- /.content-wrapper -->

        <!-- jquery-validation -->
        <script src="<?php echo e(asset('/js/jquery.validate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/additional-methods.min.js')); ?>"></script>

        <!-- DataTables  & Plugins -->
        

    </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/Admin/leftSide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical-val\resources\views/Admin/admins/create-invitation.blade.php ENDPATH**/ ?>