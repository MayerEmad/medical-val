<?php $__env->startSection('content'); ?>
<html>
    <head>
        <style>
            .badge{
                font-size: 20px;
            }
        </style>
    </head>
    <body>
        <?php if($category->parent_id==0): ?>
            <?php echo e($category_word="Category"); ?>

        <?php else: ?> 
            <?php echo e($category_word="Sub Category"); ?>

        <?php endif; ?>
        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Edit Category</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
                        <li class="breadcrumb-item active">Edit Category</li>
                        </ol>
                    </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <section class="content">

                <!-- Default box -->
                <div class="card card-solid">
                    <div class="card-body">
                        <!-- Message message -->
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                        <!-- Success message -->
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                        <div class="row">
                            <div class="col-12 col-sm-6">
                                <div class="col-12" id="imgdiv">
                                    <img id="image-previewer"  src="<?php echo e(asset('/img/categories/'.$category->image)); ?>"alt="preview image" style="max-height:500px; max-width:500px;">
                                </div>
                            </div>

                            <div class="col-12 col-sm-6">
                                <!-- form start -->
                            <form action="<?php echo e(route('category.update',['category'=>$category])); ?>" method="POST" enctype="multipart/form-data" files="true">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="card-body">
                                        <div class="form-group pt-2">
                                            <label>Category Name</label>
                                            <input type="text" name="name" class="form-control" id="category_name_id" value="<?php echo e($category->name); ?>" placeholder="Name">
                                        </div>
                                        <div class="form-group">
                                            <label><?php echo e($category_word); ?> Name in Arabic</label>
                                            <input type="text" name="ar_name" class="form-control" id="category_ar_name_id" value="<?php echo e($category->ar_name); ?>" placeholder="Arabic Name">
                                        </div>
                                        <div class="form-group pt-2">
                                            <label>Category Description</label>
                                            <textarea class="form-control" name="description" id="category_description_id"  rows="2"><?php echo e($category->description); ?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label><?php echo e($category_word); ?> Description in Arabic</label>
                                            <textarea class="form-control" name="ar_description" id="category_ar_description_id"  rows="2"><?php echo e($category->ar_description); ?></textarea>
                                        </div>
                                        <div class="form-group pt-2" style="width:200px;">
                                            <input type="file" name="image" id="theFileInput" style="display:none;"  value="<?php echo e($category->image); ?>" accept="image/*">
                                            <span onclick="useinputfile()" class="btn btn-success col-lg-12 fileinput-button">
                                                <i class="fas fa-plus"></i>
                                                <span>Edit photo</span>
                                            </span>
                                        </div>
                                        <input type="hidden" name="parent_id" value="<?php echo e($category->parent_id); ?>">
                                    </div>
                                    <!-- /.card-body -->
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                <!-- /.card -->
                   </div>
                </div>
                
            </section>
            <!-- /.content -->

        </div>
            <!-- jquery-validation -->
        <script src="<?php echo e(asset('/js/jquery.validate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/additional-methods.min.js')); ?>"></script>
        <!-- Select2 -->
        <script src="<?php echo e(asset('/js/select2.full.min.js')); ?>"></script>
        <!-- Bootstrap4 Duallistbox -->
        <script src="<?php echo e(asset('/js/jquery.bootstrap-duallistbox.min.js')); ?>"></script>
        <!-- InputMask -->
        <script src="<?php echo e(asset('/js/moment.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/jquery.inputmask.min.js')); ?>"></script>
        <!-- date-range-picker -->
        <script src="<?php echo e(asset('/js/daterangepicker.js')); ?>"></script>
        <!-- bootstrap color picker -->
        <script src="<?php echo e(asset('/js/bootstrap-colorpicker.min.js')); ?>"></script>
        <!-- Tempusdominus Bootstrap 4 -->
        <script src="<?php echo e(asset('/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
        <!-- Bootstrap Switch -->
        <script src="<?php echo e(asset('/js/bootstrap-switch.min.js')); ?>"></script>
        <!-- BS-Stepper -->
        <script src="<?php echo e(asset('/js/bs-stepper.min.js')); ?>"></script>
        <!-- dropzonejs -->
        <script src="<?php echo e(asset('/js/dropzone.min.js')); ?>"></script>
    </body>
        

        <script>
            $('#theFileInput').change(function()
            {       
                if (this.files && this.files[0]) 
                {
                    let reader = new FileReader();
                    reader.onload = (e) => { 
                        $('#image-previewer').attr('src', e.target.result); 
                    }
                    reader.readAsDataURL(this.files[0]);
                    $('#deletebtn').show(); 
                }
            });
    
        function useinputfile()
        {
            $('#theFileInput').click();
        }
        function deleteImage()
        {
            //not used here
            $("#imgdiv img:last-child").remove()
            $("#imgdiv").append('<img id="image-previewer" src="https://www.riobeauty.co.uk/images/product_image_not_found.gif"alt="preview image" style="max-height: 250px;">');
            $('#theFileInput').val(null);
            $('#deletebtn').hide(); 
        }
        </script>
    
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/Admin/leftSide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical-val\resources\views/Admin/category/edit.blade.php ENDPATH**/ ?>