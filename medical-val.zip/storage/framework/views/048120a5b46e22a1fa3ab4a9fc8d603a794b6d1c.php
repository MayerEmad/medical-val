<?php $__env->startComponent('mail::message'); ?>
Hello **<?php echo e($name); ?>**,  
Welcome to SaidalyiaOnline WebSite as Admin!  
This Link will expire after 10 m
<?php $__env->startComponent('mail::button', ['url' => $link]); ?>
Login Now
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
Mayer Emad Milad :)
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\medical-val\resources\views/Admin/admins/mail.blade.php ENDPATH**/ ?>