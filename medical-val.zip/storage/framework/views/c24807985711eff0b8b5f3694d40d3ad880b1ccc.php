<?php $__env->startSection('content'); ?>
<html>
    <head>
        <!-- DataTables -->
        <link rel="stylesheet" href="<?php echo e(asset('/css/dataTables.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/css/responsive.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/css/buttons.bootstrap4.min.css')); ?>">
    </head>
    <body>
        <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Add New Admin</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
                        <li class="breadcrumb-item active">Add New Admin</li>
                        </ol>
                    </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- jquery validation -->
                        <div class="card card-primary">

                        <!-- form start -->
                        <form action="" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <div class="form-group">
                                    <label >Name</label>
                                    <input type="text" name="name" class="form-control" id="name" placeholder="Enter Admin Name">
                                </div>
                                <div class="form-group">
                                    <label >Email address</label>
                                    <input type="email" name="email" class="form-control" id="email" placeholder="Enter Admin Email">
                                </div>
                                <div class="form-group">
                                    <label >Password</label>
                                    <input type="password" name="password" class="form-control" id="password" placeholder="Password">
                                </div>
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Send</button>
                                </div>
                            </div>
                        </form>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                        </div>
                    </div>
                    <!-- /.row -->
                </div><!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        </div>
        <!-- /.content-wrapper -->

        <!-- jquery-validation -->
        <script src="<?php echo e(asset('/js/jquery.validate.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/additional-methods.min.js')); ?>"></script>

        <!-- DataTables  & Plugins -->
        <!-- <script src="<?php echo e(asset('/js/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/dataTables.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/responsive.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/buttons.bootstrap4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/pdfmake.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/vfs_fonts.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/buttons.colVis.min.js')); ?>"></script> -->

    </body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('/Admin/leftSide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical-val\resources\views/Admin/admins/create.blade.php ENDPATH**/ ?>